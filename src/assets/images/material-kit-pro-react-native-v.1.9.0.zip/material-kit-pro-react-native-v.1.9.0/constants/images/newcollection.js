export default [
  {
    title: 'Brand new Autumn gear for every man...',
    // image: 'https://source.unsplash.com/KJG6KBFPLDM/840x840',
    image: 'https://images.unsplash.com/uploads/14126691796798a85b1b0/970ca552?crop=entropy&w=840&h=840&fit=crop',
    price: 180,
    horizontal: true,
  },
  {
    title: "Bird lovers can enjoy the new collection...",
    // image: 'https://source.unsplash.com/DhV4_WC9g28/840x840',
    image: 'https://images.unsplash.com/photo-1513043105799-ba3f53df3ab7?crop=entropy&w=840&fit=crop',
    price: 220,
  },
  {
    title: "Pottery brand new courses just for...",
    // image: 'https://source.unsplash.com/JT3W6P1mYtU/840x840',
    image: 'https://images.unsplash.com/photo-1523263666618-c992b26eec21?crop=entropy&w=840&h=840&fit=crop',
    price: 40,
  },
  {
    title: "New Collection of hand-made red paper...",
    // image: 'https://source.unsplash.com/OMgCJf8LCig/840x840',
    image: 'https://images.unsplash.com/photo-1543342578-aedb05536855?crop=entropy&w=840&h=840&fit=crop',
    price: 188,
    horizontal: true,
  },
  {
    title: 'Add a trip to Bellagio Hotel to your...',
    // image: 'https://source.unsplash.com/kKV4bLwSc_4/840x840',
    image: 'https://images.unsplash.com/photo-1543321269-9d86d3680e1c?crop=entropy&w=840&h=840&fit=crop',
    price: 180,
  },
];