export default [
  {
    title: 'Affordable ladies fashion for every occasion.',
    // image: 'https://source.unsplash.com/mEZ3PoFGs_k/840x840',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?crop=entropy&w=840&h=840&fit=crop',
    price: 180,
    horizontal: true,
  },
  {
    title: 'Shop current season to classic in our...',
    // image: 'https://source.unsplash.com/8Zv6hOS_STE/840x840',
    image: 'https://images.unsplash.com/photo-1542838686-b08706f6f2d1?crop=entropy&w=840&fit=crop',
    price: 220,
  },
  {
    title: "Stand out from the crowd with the...",
    // image: 'https://source.unsplash.com/BKxipJKe3G0/840x840',
    image: 'https://images.unsplash.com/photo-1503066375319-00fef06b159e?crop=entropy&w=840&h=840&fit=crop',
    price: 40,
  },
  {
    title: "Women's sport sometimes seems to...",
    // image: 'https://source.unsplash.com/kFCdfLbu6zA/840x840',
    image: 'https://images.unsplash.com/photo-1445384763658-0400939829cd?crop=entropy&w=840&h=840&fit=crop',
    price: 188,
    horizontal: true,
  },
  {
    title: 'The Glamour Awards is an annual...',
    // image: 'https://source.unsplash.com/ZOT2Mewzmh8/840x840',
    image: 'https://images.unsplash.com/photo-1499313843378-eebdb187f629?crop=entropy&w=840&h=840&fit=crop',
    price: 180,
  },
];